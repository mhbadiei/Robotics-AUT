#! /usr/bin/env python

# Import the Python library for ROS
import rospy

from matplotlib import pyplot as plt
from matplotlib.patches import Rectangle

# Import the Twist message from the geometry_msgs package
# Twist data structure is used to represent velocity components
from geometry_msgs.msg import Twist

# Import the Odometry message
from nav_msgs.msg import Odometry

# TF allows to perform transformations between different coordinate frames
import tf


# For getting robot’s ground truth from Gazebo
from gazebo_msgs.srv import GetModelState


class PathVelocityGen():
    
    def __init__(self):
        # Initiate a node named’ path_velocity’
        rospy.init_node('path_velocity')
    
        # Create a Publisher object, that will publish on /new_vel topic
        # messages of type Twist
        self.vel_pub = rospy.Publisher('/new_vel', Twist, queue_size=1)
    
        # Creates var of type Twist
        self.vel = Twist()
    
        # Assign initial velocities
        self.vel.linear.x = 0.45    # m/s
        self.vel.angular.z = 0    # rad/s
        
        
        # Subscribe to topic /odom published by the robot base
        self.odom_sub = rospy.Subscriber('/odom', Odometry, self.callback_odometry)
        
        # Subscribe to topic /change published by move_robot
        self.vel_change_sub = rospy.Subscriber('/change', Twist,self.callback_velocity_change)
        self.pose_x_msg = 0
        self.pose_y_msg = 0
        self.orientation_z = 0
        
        self.report_pose = False
        self.x = list()
        self.y = list()
        self.final_round_error = list()
        self.round = 10
        

        
        #subscribe to a service server,provided by the gazebo package to get
        #information about the state of the models present in the simulation
        
        print("Wait for service ....")
        rospy.wait_for_service("gazebo/get_model_state")
        
        print(" ... Got it!")
        
        self.get_ground_truth = rospy.ServiceProxy("gazebo/get_model_state",GetModelState)

    def callback_velocity_change(self, msg):
        rospy.loginfo("Velocity has changed, now: %5.3f, %5.3f",msg.linear.x, msg.angular.z)
        rospy.sleep(0) # to let the velocity being actuated and odometry updated
        self.report_pose = True
        
    def callback_odometry(self, msg):
        if self.report_pose == True:
            self.quaternion_to_euler(msg)
            
            self.pose_x_msg = msg.pose.pose.position.x
            self.pose_y_msg = msg.pose.pose.position.y
            
            self.report_pose = False
            
    def quaternion_to_euler(self, msg):
        quaternion = (msg.pose.pose.orientation.x, msg.pose.pose.orientation.y,msg.pose.pose.orientation.z, msg.pose.pose.orientation.w)
        self.orientation_z = msg.pose.pose.orientation.z
        (roll, pitch, yaw) = tf.transformations.euler_from_quaternion(quaternion)
        #print ("Roll: %5.2f  Pitch: %5.2f  Yaw: %5.2f" % (roll, pitch, yaw))
        
    def path_values(self):
        i = 0
        flag = False      
        flag2 = False    
        main_flag= False      
        # Loop until someone stops the program execution
        while not rospy.is_shutdown():
            
            #self.vel.linear.x  = 0.45
            #self.vel.angular.z = 0
            
            
            print("x : ",self.pose_x_msg)
            print("y : ",self.pose_y_msg)
            print("O z: ",self.orientation_z)
            
            if main_flag == True:
                self.vel.linear.x  = 0.0
                self.vel.angular.z = 0.0                
            elif i < self.round:
            
                if self.pose_x_msg >= 1.1 and self.pose_y_msg <= 1.1:
                    if abs(self.orientation_z<0.69):
                        self.vel.linear.x  = 0.1
                        self.vel.angular.z = 0.2
                    elif abs(self.orientation_z>=0.74):
                        self.vel.linear.x  = 0.1
                        self.vel.angular.z = -0.2
                    else :
                        self.vel.linear.x  = 0.45
                        self.vel.angular.z = 0.0
                    flag = False
                    if i == self.round-1:
                        self.final_round_error.append(abs(1.5 - self.pose_x_msg))                     
                elif self.pose_x_msg >= -1.1 and self.pose_x_msg >= 1.1:
                    if not flag2:
                        if abs(self.orientation_z<0.999):
                            self.vel.linear.x  = 0.1
                            self.vel.angular.z = 0.3
                        else :
                            self.vel.linear.x  = 0.25
                            self.vel.angular.z = 0.0
                            flag2 = True
                    else :
                        self.vel.linear.x  = 0.45
                        self.vel.angular.z = 0.0

                    if i == self.round-1:
                        self.final_round_error.append(abs(1.5 - self.pose_y_msg))                     
                   
                elif self.pose_x_msg <= -1.1 and self.pose_y_msg >= -1.1:
                    flag2 = False
                    if abs(self.orientation_z<0.67):
                        self.vel.angular.z = -0.25
                    elif abs(self.orientation_z>=0.7):
                        self.vel.linear.x  = 0.1
                        self.vel.angular.z = 0.25
                    else :
                        self.vel.linear.x  = 0.45
                        self.vel.angular.z = 0.0
                            
                    if i == self.round-1:
                        self.final_round_error.append(abs(-1.5 - self.pose_x_msg))                     
                
                elif self.pose_x_msg <= 1.1 and self.pose_y_msg <= -1.1:
                    
                    if abs(self.orientation_z<-0.05):
                        self.vel.linear.x  = 0.1
                        self.vel.angular.z = 0.25
                    elif abs(self.orientation_z>=0.05):
                        self.vel.linear.x  = 0.0
                        self.vel.angular.z = -0.25
                        if not flag:
                            i += 1
                            flag = True
                            #print("*****************************")
                            #print(i)
                    else :
                        self.vel.linear.x  = 0.45
                        self.vel.angular.z = 0.0
                    if i == self.round-1:
                        self.final_round_error.append(abs(-1.5 - self.pose_y_msg))                     
                else:
                    self.final_round_error.append(abs(1.5 - self.pose_x_msg))   
                self.x.append(self.pose_x_msg)
                self.y.append(self.pose_y_msg)
            else :
                self.vel.linear.x  = 0.0
                self.vel.angular.z = 0.0
                
                
                plt.figure()
                plt.plot(self.x, self.y,label='robot trajectory')
                plt.xlabel('x - axis')
                plt.ylabel('y - axis')
                plt.title('trajectory of robot')
                
                
                k = list()
                for n in range(len(self.final_round_error)):
                    k.append(n)
                
                plt.figure()
                plt.plot(k,self.final_round_error)
                plt.xlabel('samples of error')
                plt.ylabel('MEAn ABSOLUTE ERROR CRITERIA')
                plt.title('continued samples of error')
                plt.show() 
                main_flag = True
            
            self.vel_pub.publish(self.vel)
            
            now = rospy.get_rostime()
            print ("Time now: ", now.secs)
            
            next = (0.0)
            
            rospy.loginfo("Twist: [%5.3f, %5.3f], next change in %5.3f secs - ",self.vel.linear.x, self.vel.angular.z, next)
            
            rospy.sleep(next)           # Sleeps for the selected seconds
            
if __name__ == '__main__':
    try:
        generator = PathVelocityGen()
    
        generator.path_values()
    
    except rospy.ROSInterruptException:
        pass
        
        
        
        
